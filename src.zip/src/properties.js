export const properties = {
  url: "https://myprosk.com",
  //url: "https://dev.myprosk.com",
  };
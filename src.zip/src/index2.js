import React from 'react';
import ReactDOM from 'react-dom';
const App = () => (
<div>
<h1>Hello world  dfgdfgdfgfdgsdfsdfsdfsdfsdfsdfsdfsdf 2!!</h1>
</div>
)
ReactDOM.render(<App/>, document.getElementById('root'));
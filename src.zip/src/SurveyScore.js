import React, { useState, useCallback } from "react";
import { withStyles } from "@material-ui/styles";
import Medicine from "./images/thankyou.png";
import GaugeChart from 'react-gauge-chart'
import TextField from "@material-ui/core/TextField";
import ArrowBackIcon from '@material-ui/icons/ArrowBack';
import {
  Grid,
  IconButton,
  Typography,
  Paper,
  Card,
  CardContent,
  CardHeader,
  Divider,
  List,
  ListItem,
  Dialog,
  DialogTitle,
  DialogContent,
  DialogContentText,
  DialogActions,
  colors,
  Button,
} from "@material-ui/core";
//import Autocomplete from '@material-ui/lab/Autocomplete';
import * as moment from "moment";
import AppBar from "@material-ui/core/AppBar";
import Toolbar from "@material-ui/core/Toolbar";
import ExitToAppIcon from "@material-ui/icons/ExitToApp";
import HomeIcon from "@material-ui/icons/Home";
import DoneIcon from "@material-ui/icons/Done";

let suggestions = [];

let course_code_data = [];
let course_account_data = [];
const useStyles = (theme) => ({
  downShift: {
    paddingTop: "18px !important",
  },
  textFieldCard: {
    paddingTop: "0px !important",
  },
  cardcontent: {
    paddingTop: "0px !important",
    paddingLeft: "4px",
    paddingRight: "4px",
    "&:last-child": {
      paddingBottom: 0,
    },
  },
  asdf: {
    margin: 1000,
  },
  root: {
    flexGrow: 1,
  },
  grow: {
    flexGrow: 1,
  },
  menuButton: {
    marginLeft: -12,
    marginRight: 20,
  },
  title: {
    display: "none",
  },

  sectionDesktop: {
    display: "none",
  },
  sectionMobile: {
    display: "flex",
  },

  card: {
    marginLeft: "10px",
    marginRight: "10px",
    marginTop: "10px",
  },
  formControl: {
    minWidth: 120,
    width: "100%",
  },
  container: {
    marginTop: "100px",
  },
});

function DenseAppBar(props) {
  const { classes } = props;
  const handleMenu = (event) => {
    window.location = "#/";
  };
  return (
    <div className={classes.root}>
     <AppBar position="fixed">
        <Toolbar variant="dense">
          <div className={classes.grow}/>
          <div>
            <IconButton color="inherit" onClick={handleMenu}>
              <ExitToAppIcon />   Logout 
            </IconButton>
          </div>
        </Toolbar>
      </AppBar>
    </div>
  );
}
class SurveyScore extends React.Component {
  constructor(props) {
    super(props);

    this.state = {
      appointment_id: localStorage.getItem("AppointmentID"),
      pain:"",
      Physical_function:"",
      Depression:"",
      Hip_Score:"",
      Knee_Score:"",
    };
  }
  handleMenu = (event) => {
    window.location = "#/Prosk/ShowAllUpcomingAppointmentListView";
  };

  ServeyScoring=()=> {
    let url = localStorage.getItem("url") +"/MobileGetQuestionMarks?appointment_id="+this.state.appointment_id;
        fetch(url, {
          method: "GET",
          //body: data
        })
          .then(res => res.json())
          .then(
            (json) => {
              console.log(url);
              if (json.success === "1") {
                this.setState({
                  pain: parseFloat("0."+json.pain_value),
                  Physical_function: parseFloat("0."+json.Physical_string) ,
                  Depression:parseFloat("0."+json.depression_string),
                  Hip_Score:parseFloat("0."+json.hoos_string),
                  Knee_Score:parseFloat("0."+json.koos_string),
                })
                console.log(this.state.pain);
                console.log(this.state.Physical_function);
                console.log(this.state.Depression);
                console.log(this.state.Hip_Score);
                console.log(this.state.Knee_Score);
              }
              else {
                alert(json.SYSTEM_MESSAGE)
              }
            },
            // Note: it's important to handle errors here
            // instead of a catch() block so that we don't swallow
            // exceptions from actual bugs in components.
            (error) => {
            }
          )
      }
      componentDidMount() {

        this.ServeyScoring();
      }
  render() {
    const { classes } = this.props;

    return (
      <div className={classes.root}>
        <form>
        <AppBar position="fixed">
          <Toolbar variant="dense">
          <IconButton color="inherit" onClick={this.handleMenu}>
              <ArrowBackIcon /> <Typography
                color="inherit"
                noWrap
              >
                Back
            </Typography>
            </IconButton>
            <div className={classes.grow} />
            <Typography
              variant="h6"
              color="inherit"
              noWrap
              style={{ textAlign: "center" }}
            >
              Survey Score
            </Typography>
            <div className={classes.grow}> </div>

          </Toolbar>
        </AppBar>
          <div
            style={{
              marginTop: "60px",
              marginBottom: "60px",
              display: "flex",
              justifyContent: "center",
              alignItems: "center",
            }}
          >
            <Card style={{ width: "98%" }}>
              <CardContent>
                <Grid container spacing={8}>
                <Grid item xs={12} sm={12}>
                <Typography
            variant="h6"
            color="inherit"
            noWrap
            style={{textAlign:"left",fontFamily:"Arial",marginBottom:"-18px"}}
          >
            Pain Interface
          </Typography>
                  </Grid>
                 
                  
                  <Grid item xs={4} sm={4}></Grid>
                  <Grid item xs={4} sm={4}>
                  <GaugeChart id="gauge-chart5" 
                  textColor={"black"}
  nrOfLevels={400}
  arcsLength={[0.2, 0.5, 0.2]}
  colors={['#5BE12C', '#F5CD19', '#EA4228']}
  percent={this.state.pain}
  arcPadding={0.03}
  style={{marginTop:"-50px"}}
/>
                  </Grid>
                  <Grid item xs={4} sm={4}></Grid>
          <Grid item xs={12} sm={12}>
                <Typography
            variant="h6"
            color="inherit"
            noWrap
            style={{textAlign:"left",fontFamily:"Arial",marginBottom:"-18px"}}
          >
            Physical Function
          </Typography>
                  </Grid>
                
                  
                  <Grid item xs={4} sm={4}></Grid>
                  <Grid item xs={4} sm={4}>
                  <GaugeChart id="gauge-chart11" 
                  textColor={"black"}
  nrOfLevels={400}
  arcsLength={[0.2, 0.5, 0.2]}
  colors={['#5BE12C', '#F5CD19', '#EA4228']}
  percent={this.state.Physical_function}
  arcPadding={0.03}
  style={{marginTop:"-50px"}}
/>
                  </Grid>
                  <Grid item xs={4} sm={4}></Grid>
                  <Grid item xs={12} sm={12}>
                <Typography
            variant="h6"
            color="inherit"
            noWrap
            style={{textAlign:"left",fontFamily:"Arial",marginBottom:"-18px"}}
          >
            Depression
          </Typography>
                  </Grid>
               
                  <Grid item xs={4} sm={4}></Grid>
                  
                  <Grid item xs={4} sm={4}>
                  <GaugeChart id="gauge-chart10" 
                  textColor={"black"}
  nrOfLevels={400}
  arcsLength={[0.2, 0.5, 0.2]}
  colors={['#5BE12C', '#F5CD19', '#EA4228']}
  percent={this.state.Depression}
  arcPadding={0.03}
  style={{marginTop:"-50px"}}
/>
                  </Grid>
                  <Grid item xs={4} sm={4}></Grid>
                  <Grid item xs={12} sm={12}>
                <Typography
            variant="h6"
            color="inherit"
            noWrap
            style={{textAlign:"left",fontFamily:"Arial",marginBottom:"-18px"}}
          >
            Hip Score
          </Typography>
                  </Grid>
              
                  <Grid item xs={4} sm={4}></Grid>
               
                  <Grid item xs={4} sm={4}>
                  <GaugeChart id="gauge-chart9" 
                  textColor={"black"}
  nrOfLevels={400}
  arcsLength={[0.2, 0.5, 0.2]}
  colors={['#5BE12C', '#F5CD19', '#EA4228']}
  percent={this.state.Hip_Score}
  arcPadding={0.03}
  style={{marginTop:"-50px"}}
/>
                  </Grid>
                  <Grid item xs={4} sm={4}></Grid>
                  <Grid item xs={12} sm={12}>
                <Typography
            variant="h6"
            color="inherit"
            noWrap
            style={{textAlign:"left",fontFamily:"Arial",marginBottom:"-18px"}}
          >
            Knee Score
          </Typography>
                  </Grid>
                  <Grid item xs={4} sm={4}></Grid>
                  <Grid item xs={4} sm={4}>
                  <GaugeChart id="gauge-chart8" 
                  textColor={"black"}
  nrOfLevels={400}
  arcsLength={[0.2, 0.5, 0.2]}
  colors={['#5BE12C', '#F5CD19', '#EA4228']}
  percent={this.state.Knee_Score}
  arcPadding={0.03}
  style={{marginTop:"-50px"}}
/>
                  </Grid>
                  <Grid item xs={4} sm={4}></Grid>
                </Grid>
              </CardContent>
            </Card>

          </div>
        </form>
      </div>
    );
  }
}
export default withStyles(useStyles)(SurveyScore);

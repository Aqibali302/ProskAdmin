export const _setSession = {
  type: "setSession",
  user_id: 123
};
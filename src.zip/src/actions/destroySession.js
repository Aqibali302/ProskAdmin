export const destroySession = {
  type: "destroySession",
  user_id: 0
};